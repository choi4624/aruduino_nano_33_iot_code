# Example application for `example` component

## What the example does

The example does nothing but waits in a loop.

## Configuration

No configuration is available.

## Notes

This is an example application of `example`. It is intended as an example
application for new component.

The code under `main` should conform the code style.
