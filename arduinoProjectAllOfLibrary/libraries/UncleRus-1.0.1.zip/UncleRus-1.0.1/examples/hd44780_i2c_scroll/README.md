# What the example does

It prints "LEFT scroll" or "RIGHT scroll" to the LCD, scrolls the text, and
repeat.
