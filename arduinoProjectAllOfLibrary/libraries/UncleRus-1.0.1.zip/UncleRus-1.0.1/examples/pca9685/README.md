# Example for `pca9685`

In this example, PWM frequency is first set to ~1500Hz
and then PWM values for channels 0 and 3 start to change
continuously.

- Channel 0: from 0 to 4096
- Channel 3: from 4096 downto 0
